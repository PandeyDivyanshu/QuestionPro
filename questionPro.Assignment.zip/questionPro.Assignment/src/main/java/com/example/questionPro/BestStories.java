package com.example.questionPro;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service
public class BestStories {

	@Cacheable(value="beststories")  
	public ArrayList<StringBuffer> getBestStroies(int limit) {

		System.out.println("customer information from cache from bestStories class");

		String readLine = null;
		StringBuffer response = new StringBuffer();
		StringBuffer detailResponses = new StringBuffer();
		ArrayList<StringBuffer> detailArr = new ArrayList<>();
		String[]  str = new String[10];
		int j = 0;
		
		try {
	
			URL urlForGetRequest = new URL("https://hacker-news.firebaseio.com/v0/beststories.json?print=pretty");
			HttpURLConnection conection = (HttpURLConnection) urlForGetRequest.openConnection();
			conection.setRequestMethod("GET");
			int responseCode = conection.getResponseCode();

			if (responseCode == HttpURLConnection.HTTP_OK) {
				BufferedReader in = new BufferedReader(
						new InputStreamReader(conection.getInputStream()));

				while ((readLine = in .readLine()) != null) {
					response.append(readLine);
				}
				
				in.close();
			}
			String res1 = response.toString().replace("[ ", " ");
			String res2 = res1.toString().replace(" ]", " ");
			//System.out.println("response array is:::"+ response.toString());
			String[] st = res2.split(",");

			for(int i=limit; i<limit+10; i++) {

				str[j] = st[i].replaceAll("\\s", "");
				//System.out.println("str[j] is::"+ str[j]);
				
				URL getRequest = new URL("https://hacker-news.firebaseio.com/v0/item/"+str[j]+".json?print=pretty");
				HttpURLConnection conn = (HttpURLConnection) getRequest.openConnection();
				conn.setRequestMethod("GET");
				int detailResponse = conn.getResponseCode();

				if (detailResponse == HttpURLConnection.HTTP_OK) {
					BufferedReader br = new BufferedReader(
							new InputStreamReader(conn.getInputStream()));

					while ((readLine = br .readLine()) != null) {
						detailResponses.append(readLine);
					}
					br.close();
					//System.out.println("detailResponses is::"+ detailResponses);

					detailArr.add(detailResponses);
					j++;

				}else {
					System.out.println("GET NOT WORKED");
				}
				}
	} catch (ProtocolException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	return detailArr;
}

}
