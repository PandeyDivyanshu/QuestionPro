package com.example.questionPro;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController  
public class Controller {
	
	@Autowired
	private BestStories bestStories;
	
	@Autowired
	private PastStories pastStories;
	
	@Autowired
	private Comments comment;
	
	int limit =0;
	
	@RequestMapping("/best-stories")  
	public String bestStroies()
	{  
		
		ArrayList<StringBuffer> resp = bestStories.getBestStroies(limit);

		return resp.toString();  
	}  
	
	@RequestMapping("/past-stories")  
	public String pastStories ()
	{  
		
		StringBuffer resp = pastStories.getPastStroies();

		return resp.toString();  
	}  
	
	@RequestMapping("/comments")  
	public String comments ()
	{  
		
		ArrayList<String>  resp = comment.getBestComments();

		return resp.toString();  
	}  
	
	@RequestMapping("/clearCache") 
	@CacheEvict(value= {"beststories","comments","paststories"}, allEntries = true)  
	@Scheduled(cron = "0 0/15 * * * ?")
	public void clearCache()   
	{  
		limit = limit+10;
		System.out.println("Cleared cache");
	} 
}
