package com.example.questionPro;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service
public class PastStories {

	@Cacheable(value="paststories")  
	public StringBuffer getPastStroies() {

		System.out.println("customer information from cache from PastStories class");

		String readLine = null;
		StringBuffer response = new StringBuffer();
		
		try {
	
			URL urlForGetRequest = new URL("https://hacker-news.firebaseio.com/v0/jobstories.json?print=pretty");
			HttpURLConnection conection = (HttpURLConnection) urlForGetRequest.openConnection();
			conection.setRequestMethod("GET");
			int responseCode = conection.getResponseCode();

			if (responseCode == HttpURLConnection.HTTP_OK) {
				BufferedReader in = new BufferedReader(
						new InputStreamReader(conection.getInputStream()));

				while ((readLine = in .readLine()) != null) {
					response.append(readLine);
				}
				
				in.close();
			}
			else {
					System.out.println("GET NOT WORKED");
				}
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	return response;

	}
}
